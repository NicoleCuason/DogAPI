
- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh

1. This project is about Dog Breeds based on The Dog API, where one can view different breeds of dogs, their information, images and vital details.

2. This is the link I used, similar to my second honework in Web Scripting 2: https://www.youtube.com/watch?v=G6D9cBaLViA.

How I started to create my project: 

-Go to Terminal Window of VS Code, then type "npm create vite@latest", then the project name is "frontend". 

-Go to "React">"JavaScript", then type "cd frontend". Next is "npm install", and lastly is "npm run dev". 

The local host is- "https://localhost:5173"

As it refreshes, go back to Terminal Window in VS Code then type "npm install react-router-dom"; then type again "npm run dev". 

Here is the API Key of the Dog API in my code (but this is given by my email): "live_uAwSKOnAoi3HwsQFSb5YR4d81FarlotKluaRjTBPfW3JoAzL8Go0VeKfWbecKR3S".

URL: "https://api.thedogapi.com/v1"

DOG API LINK: "https://www.thedogapi.com"


Other References: ChatGPT (for inspection and clarification), Lecture Slides from Web Design and other coding courses in Learning Hub D2L, and W3 Schools Website



